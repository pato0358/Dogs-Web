import { useState, useEffect } from "react";
import { Link, useHistory } from "react-router-dom";
import { postDog, getTemperaments } from "../actions/index";
import { useDispatch, useSelector } from "react-redux";
import "./DogCreate.css";


export default function DogCreate() {
  const dispatch = useDispatch();
  const history = useHistory();
  const temps = useSelector((state) => state.allTemperaments);
  // const [errors, setErrors] = useState({});

  const [input, setInput] = useState({
    name: "",
    weightMin: "",
    weightMax: "",
    heightMin: "",
    heightMax: "",
    life_span: "",
    image:"",
    temperaments: [],
  });

  function handleChange(e) {
    setInput({
      ...input,
      [e.target.name]: e.target.value,
    });
   
  }

  function handleSelect(e) {
    setInput({
      ...input,
      temperaments: [...input.temperaments, e.target.value],
    });
  }

  function handleSubmit(e) {
    e.preventDefault();
    console.log(input);
    const {
      name,
      weight,
      height,
      weightMin,
      weightMax,
      heightMin,
      heightMax,
      life_span,
      image,
    } = input;
    if (name === undefined || name.length < 3) {
      return alert("Name is invalid");
    } else if (
      weightMin > weightMax ||
      weightMin === undefined ||
      weightMax === undefined
    ) {
      setInput({
        ...input,
        weightMin: "",
        weightMax: "",
      });
      return alert(
        "Weight is undefined or minimum weight is greater than the maximun weight"
      );
    } else if (
      heightMin > heightMax ||
      heightMin === undefined ||
      heightMax === undefined
    ) {
      setInput({
        ...input,
        heightMin: "",
        heightMax: "",
      });
      return alert(
        "Height is undefined or minimum height is greater than the maximun height"
      );
    } else if (life_span < 1 || life_span > 50) {
      return alert("Life span can't be less than 1 or greater than 50");
    } else {
      input.weight = weightMin + " - " + weightMax;
      input.height = heightMin + " - " + heightMax;
      delete input.weightMin;
      delete input.weightMax;
      delete input.heightMin;
      delete input.heightMax;
     
    }

    dispatch(postDog(input));
    alert("Breed created succesfuly");
    setInput({
      name: "",
      weightMin: "",
      weightMax: "",
      heightMin: "",
      heightMax: "",
      life_span: "",
      image:"",
      temperaments: [],
    });
    history.push("/home");
  }

  function handleDelete(el) {
    setInput({
      ...input,
      temperaments: input.temperaments.filter((temps) => temps !== el),
    });
  }

  useEffect(() => {
    dispatch(getTemperaments());
  }, []);

  return (
    <div className="post">
      <Link to="/home">
        <button>Home</button>
      </Link>
      <h1>Create your own breed!</h1>
      <form onSubmit={(e) => handleSubmit(e)}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={input.name}
            name="name"
            onChange={(e) => handleChange(e)}
          />
          {/* {errors.name && <p>{errors.name}</p>} */}
        </div>
        <div>
          <lable>Weight:</lable>
          <input
            type="text"
            placeholder="Min"
            value={input.weightMin}
            name="weightMin"
            onChange={(e) => handleChange(e)}
          />
          <input
            type="text"
            placeholder="Max"
            value={input.weightMax}
            name="weightMax"
            onChange={(e) => handleChange(e)}
          />
          {/* {errors.weight && <p>{errors.weight}</p>} */}
        </div>
        <div>
          <lable>Height:</lable>
          <input
            type="text"
            placeholder="Min"
            value={input.heightMin}
            name="heightMin"
            onChange={(e) => handleChange(e)}
          />
          <input
            type="text"
            placeholder="Max"
            value={input.heightMax}
            name="heightMax"
            onChange={(e) => handleChange(e)}
          />
          {/* {errors.height && <p>{errors.height}</p>} */}
        </div>
        <div>
          <lable>Life span:</lable>
          <input
            type="number"
            value={input.life_span}
            name="life_span"
            onChange={(e) => handleChange(e)}
          />
          {/* {errors.life_span && <p>{errors.life_span}</p>} */}
        </div>
        <div>
          <label>Image:</label>
          <input
            type="text"
            value={input.image}
            name="image"
            onChange={(e) => handleChange(e)}
          />
        </div>
        <div>
          <label>Temperaments:</label>
          <select onChange={(e) => handleSelect(e)}>
            {" "}
            Temperaments:
            {temps.map((el) => (
              <option value={el.name}>{el.name}</option>
            ))}
          </select>
        </div>
        <ul>
          <li>{input.temperaments.map}</li>
        </ul>
        <button type="submit">Create breed</button>
      </form>
      {input.temperaments.map((el) => (
        <div>
          <p>{el}</p>
          <button onClick={() => handleDelete(el)}>x</button>
        </div>
      ))}
    </div>
  );
}
