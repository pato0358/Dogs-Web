import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { getDogs } from "../actions";

export default function Details(props) {
  console.log(props);

  const dispatch = useDispatch();
  const allDogs = useSelector((state) => state.allDogs);
  const myDog = allDogs.find((dog) => dog.id == props.match.params.id);

  useEffect(() => {
    if (allDogs.length == 0) dispatch(getDogs());
  }, [dispatch]);

  return (
    <div>
      {myDog ? (
        <div>
          <h1>Name:{myDog.name}</h1>
          <img src={myDog.image} alt="" width="500px" height="700px" />
          <h3>
            Temperaments:
            {!myDog.createdInDb
              ? myDog.temperaments?.join(", ")
              : myDog.temperaments?.map((e) => e.name).join(", ")}
          </h3>
          <h3>Weight:{myDog.weight}</h3>
          <h3>Height:{myDog.height}</h3>
        </div>
      ) : (
        <p>Loading...</p>
      )}
      <Link to="/home">
        <button>Home</button>
      </Link>
    </div>
  );
}
